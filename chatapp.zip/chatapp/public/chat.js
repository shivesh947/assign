        const socket = io();

        const linkTemplate = document.getElementById("link-template").innerHTML;
       
        
        const chat = document.getElementById("chatform");
        const messagetext = document.getElementById("message");
        const sendBtn = document.getElementById("messageBtn");
        const messages = document.getElementById("messages");

        const scroll = ()=>{
            const newmessage =  messages.lastElementChild;

            const newMessageStyle = getComputedStyle(newmessage);
            const newMessageMargin = parseInt(newMessageStyle.marginBottom)
            const newmessageheight = newmessage.offsetHeight + newMessageMargin;
        
            const visibleHeight = messages.offsetHeight;

            const containerHeight = messages.scrollHeight;

            const scrolloffset = messages.scrollTop + visibleHeight;
            if(containerHeight - newmessageheight <= scrolloffset){
                messages.scrollTop = messages.scrollHeight;
            }
        }
                
        const messageTemplate = document.getElementById("message-template").innerHTML;
        
       
        const st = document.getElementById("st").innerHTML;

        

        chat.addEventListener("submit",(e)=>{
            e.preventDefault();

            socket.emit("sendMessage",messagetext.value,(err)=>{
                if(err){
                    return console.log(err);
                }
                messagetext.value = '';
                messagetext.focus();
                sendBtn.removeAttribute("disabled");
            });
        })
        socket.on("message",(message)=>{
            console.log(message);
            const html = Mustache.render(messageTemplate,{
                message:message.message,
                createdAt:moment(message.createdAt).format('h:mm a'),
                username:message.username
            });
            messages.insertAdjacentHTML('beforeend',html);
            scroll()
        })

        const {username,room} = Qs.parse(location.search,{ignoreQueryPrefix:true})

        socket.emit("join",{username},(error)=>{
            if(error){
                alert(error);
                location.href = "/"
            }
        });

        socket.on("roomdata",({room,users})=>{
            console.log(users);
            const html = Mustache.render(st,{
                room,
                users
            })
            document.getElementById("sidebar").innerHTML = html;
        })

        function funimage(avtar){
            document.getElementById('imagename').value=avtar;
            alert(avtar);
            if( avtar!=null || ( avtar==1 ||avtar==2 ||avtar==3 ||avtar==4 ||avtar==5))
            {
                document.getElementById('avtarselect').src=avtar
                document.getElementById('selectavtar').style.display="none";
                socket.emit("makeAdmin",avtar)
            }
      
        }
       socket.on('adminAvtar',(data)=>{
           document.getElementById('avtarselect').src=data;
        console.log(data)
       })
        socket.on('selectAvatar',()=>{
          document.getElementById('selectavtar').style.display="block";
        
        
        }
        )