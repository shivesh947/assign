const express = require('express');
const path = require('path');
const app = express();
const hbs = require('hbs');
const http = require('http');
const socketio = require('socket.io');
const Filter = require('bad-words');
const server = http.createServer(app);
const io = socketio(server);

const {addUser,getuser,getuserinroom,removeuser} = require('./utils/users');

const publicDirectoryPath = path.join(__dirname,'../public');
const viewPath = path.join(__dirname,'../templates/views');
const partialsPath = path.join(__dirname,'../templates/partials');

const port = process.env.PORT || 3000;

app.set('view engine','hbs');
app.set('views',viewPath);
hbs.registerPartials(partialsPath);
const generateMessage = require('../src/utils/messages');

app.use(express.static(publicDirectoryPath));

let count = 0;
let avtar='';
let currentAdmin = undefined;
io.on('connection',(socket)=>{
   

    socket.on("join",({username},callback)=>{
        
        if(avtar)
            socket.emit('adminAvtar',avtar);
        const {error,user} = addUser({
            id:socket.id,
            username,
        })

        if(error){
            return callback(error);
        }

        socket.join('public');

        if(!currentAdmin)
        {
            console.log("ghgh")
            io.to('public').emit("selectAvatar");
            
        }
       
        socket.emit('message',generateMessage("Admin",`welcome!`));
        socket.broadcast.to('public').emit('message',generateMessage("Admin",`${username} has just joined`));
        
        io.to('public').emit("roomdata",{
            room:'public',
            users:getuserinroom('public')
        })

        callback();
    })
    
    socket.on('makeAdmin',(Avtar)=>{
        console.log(Avtar)
        if(!currentAdmin){
            currentAdmin = getuser(socket.id).username;
        }
        avtar=Avtar;
        io.to('public').emit("adminAvtar",Avtar)
        
       
    })

    socket.on("sendMessage",(message,callback)=>{
        const user = getuser(socket.id);
        if(user.username == currentAdmin){
            io.to('public').emit("message",generateMessage(user.username,message));
            callback();
        }
    })     

    socket.on('disconnect',()=>{
        const user = removeuser(socket.id);
        if(user){
            io.to('public').emit("message",generateMessage(user.username,`${user.username} has left`));
            io.to('public').emit("roomdata",{
                users:getuserinroom('public')
            })
            if(user.username == currentAdmin)
            {
                currentAdmin = undefined;
                avtar=undefined;
                console.log(currentAdmin)
                io.to('public').emit("selectAvatar");
            }
        }
    })

    socket.on("sendLocation",(position,callback)=>{
        const user = getuser(socket.id);
        io.to('public').emit("message",generateMessage(user.username,message));
        callback();
    })

})

server.listen(port,()=>{
    console.log("server is running at "+port);
});